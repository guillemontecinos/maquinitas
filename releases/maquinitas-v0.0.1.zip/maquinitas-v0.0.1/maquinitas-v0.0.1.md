# maquinitas

this is release v0.0.1, saturday february 17th 2018.

this library so far includes:

* notes
* max patches

for the following instruments:

* critter and guitari septavox
* roland tr-505
