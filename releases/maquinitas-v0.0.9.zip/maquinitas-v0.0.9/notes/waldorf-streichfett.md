# maquinitas

## notes on waldorf streichfett

TODO
