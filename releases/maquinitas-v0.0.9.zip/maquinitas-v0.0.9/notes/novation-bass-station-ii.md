# maquinitas

## notes on novation bass station ii

TODO
