# maquinitas

## notes on roland tb-03

TODO
