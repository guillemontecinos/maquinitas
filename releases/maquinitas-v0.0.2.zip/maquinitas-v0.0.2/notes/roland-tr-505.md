# maquinitas

## notes on roland tr-505

to access midi functions press shift-midi

to go through the items on the list, press the midi button again while holding down-shift.

the items are:
* midi sync: on/off
* omnni mode (om): on/off
* receive cahnnel number (rch): 1-16
* key number of the drum voice (nbr): to see the key number of another drum voice, push the corresponding drum key.
* transmit channel of the drum voice (tch): to see the transmit channel of another drum voice, push the corresponding drum key.

to change the values, use the keys level up and down.

## drum sounds

| number| name        |
|-------|-------------|
|01     |low conga    |
|02     |hi conga     |
|03     |timbale      |
|04     |low cowbell  |
|05     |hi cowbell   |
|06     |hand clap    |
|07     |crash cymbal |
|08     |ride cymbal  |
|09     |bass drum    |
|10     |snare drum   |
|11     |low tom      |
|12     |mid tom      |
|13     |hi tom       |
|14     |rim shot     |
|15     |closed hi-hat|
|16     |open hi-hat  |
