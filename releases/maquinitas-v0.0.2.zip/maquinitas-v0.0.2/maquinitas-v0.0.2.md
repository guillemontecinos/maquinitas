# maquinitas

this is release v0.0.2, monday february 19th 2018.

this library so far includes:

* notes
* max patches

for the following instruments:

* critter and guitari septavox
* korg volca beats
* korg volca kick
* roland tr-505
