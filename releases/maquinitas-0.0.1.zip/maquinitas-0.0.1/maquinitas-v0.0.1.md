# maquinitas

this is release v0.0.1

this library so far includes:

* notes
* max patches

for the following instruments:

* critter and guitari septavox
* roland tr-505
