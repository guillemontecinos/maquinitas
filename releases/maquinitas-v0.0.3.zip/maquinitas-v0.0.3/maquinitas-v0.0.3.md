# maquinitas

this is release v0.0.3, wednesday february 21th 2018.

this library so far includes:

* maquinitas-max: patches for every instrument on max.
* notes: notes about the midi operation of every instrument.

list of instruments:

* critter and guitari septavox
* korg volca beats
* korg volca kick
* roland sh-01a
* roland tr-505
